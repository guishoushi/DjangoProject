'''
1、静态粘贴单个字母
2、静态粘贴多个字母
3、单个字母静态下落

'''
import pygame
import random

# 初始化pygame
pygame.init()

# 定义界面的宽度和高度
sc_width = 932
sc_height = 526

# 定义标题
title = "小码打字练习生"

# 设置界面大小和标题
screen = pygame.display.set_mode((sc_width, sc_height))
pygame.display.set_caption(title)

# 加载背景
backgroud = pygame.image.load("bg.png")
# 粘贴背景图片
screen.blit(backgroud, (0, 0))

# 加载中间区域透明背景
transparent_image = pygame.image.load("pp.png")

# 加载字体
font = pygame.font.Font("zh152.ttf", 50)
# 生成文字
single_word = font.render("A", True, (255, 255, 255))
screen.blit(single_word, (350, 220))

# 游戏结束
gameover_font = pygame.font.Font("zh152.ttf", 50 * 2)
gameover = font.render("GAME OVER", True, (255, 255, 255))

# 设置下落的字母列表
word_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
           'v', 'w', 'x', 'y', 'z']

# 随机字母列表
random_word_list = []
# 随机字母位置列表
position_list = []

word_y = 150
for i in range(26):
    wordindex = random.randint(0, 25)
    # 随机获取单个字母
    word = word_list[wordindex]
    # 添加进随机字母列表
    random_word_list.append(word)
    # 通过索引，设置随机取出的字母的x坐标和y坐标
    word_x = random.randint(230, 720 - 50)
    word_y = word_y - 50
    position_list.append((word_x, word_y))
# 打印字母和字母对应的坐标
#print(random_word_list)
#print(position_list)

# 实现将字母绘制在屏幕上
for i in range(len(random_word_list)):
    word = random_word_list[i]  
    text = font.render(word, True, (255, 255, 255))
    # 获取当前字母的x坐标和y坐标
    word_x, word_y = position_list[i]
    if word_y < 350 - 50:
        screen.blit(text, (word_x, word_y))


while True:
    screen.blit(backgroud, (0, 0))
    
    for i in range(len(random_word_list)):
        word = random_word_list[i]  # 重点
        text = font.render(word, True, (255, 255, 255))
        # 获取当前字母的x坐标和y坐标
        word_x, word_y = position_list[i]
        # 通过坐标粘贴字母
        if word_y < 350 - 50:
            screen.blit(text, (word_x, word_y))
        else:
            screen.blit(backgroud, (0, 0))
            screen.blit(gameover, (320, 220))  # 内左上角
            pygame.display.update()
            break

        # 当前字母的y坐标增加1
        word_y = word_y + 1
        # 更新当前字母的x坐标和y坐标
        position_list[i] = word_x, word_y
        
    # 粘贴透明背景
    screen.blit(transparent_image,(0, 0))
    
    # 刷新界面
    pygame.display.update()
